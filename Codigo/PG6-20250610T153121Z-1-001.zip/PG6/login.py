# login.py
import tkinter as tk
from tkinter import messagebox
import json
import subprocess
import os

USUARIOS_FILE = "usuarios.json"

def cargar_usuarios():
    if os.path.exists(USUARIOS_FILE):
        with open(USUARIOS_FILE, "r") as f:
            return json.load(f)
    return {}

def login():
    dni = entry_dni.get()
    contra = entry_contra.get()

    usuarios = cargar_usuarios()

    if dni in usuarios and usuarios[dni]["contraseña"] == contra:
        nombre = usuarios[dni]["nombre"]
        messagebox.showinfo("Login exitoso", f"¡Bienvenido/a, {nombre}!")
    else:
        messagebox.showerror("Error", "DNI o contraseña incorrectos.")

def ir_a_registro():
    ventana.destroy()
    subprocess.run(["python3", "Register.py"])

# Interfaz de login
ventana = tk.Tk()
ventana.title("Iniciar Sesión")
ventana.geometry("300x200")
ventana.resizable(False, False)

tk.Label(ventana, text="Número de Documento (DNI):").pack(pady=5)
entry_dni = tk.Entry(ventana, width=30)
entry_dni.pack()

tk.Label(ventana, text="Contraseña:").pack(pady=5)
entry_contra = tk.Entry(ventana, show="*", width=30)
entry_contra.pack()

tk.Button(ventana, text="Iniciar Sesión", command=login).pack(pady=10)
tk.Button(ventana, text="Registrarse", command=ir_a_registro).pack()


# --- INICIO RECUPERAR CONTRASEÑA ---
def recuperar_contraseña():
    def enviar_codigo():
        dni = entry_dni_rec.get()
        usuarios = cargar_usuarios()
        if dni in usuarios:
            codigo = "123456"  # Aquí se puede generar uno aleatorio real
            messagebox.showinfo("Código enviado", f"Tu código es: {codigo}")
            ventana_codigo(codigo, dni)
            ventana_rec.destroy()
        else:
            messagebox.showerror("Error", "DNI no encontrado.")

    ventana_rec = tk.Toplevel()
    ventana_rec.title("Recuperar Contraseña")
    ventana_rec.geometry("300x150")

    tk.Label(ventana_rec, text="Introduce tu DNI:").pack(pady=5)
    entry_dni_rec = tk.Entry(ventana_rec, width=30)
    entry_dni_rec.pack()

    tk.Button(ventana_rec, text="Enviar Código", command=enviar_codigo).pack(pady=10)

def ventana_codigo(codigo_real, dni):
    def verificar_codigo():
        if entry_codigo.get() == codigo_real:
            cambiar_contraseña(dni)
            ventana_cod.destroy()
        else:
            messagebox.showerror("Código incorrecto", "El código no es válido.")

    ventana_cod = tk.Toplevel()
    ventana_cod.title("Verificar Código")
    ventana_cod.geometry("300x150")

    tk.Label(ventana_cod, text="Introduce el código recibido:").pack(pady=5)
    entry_codigo = tk.Entry(ventana_cod, width=30)
    entry_codigo.pack()

    tk.Button(ventana_cod, text="Verificar", command=verificar_codigo).pack(pady=10)

def cambiar_contraseña(dni):
    def guardar_nueva_contra():
        nueva = entry_nueva.get()
        confirmar = entry_confirmar.get()
        if nueva != confirmar:
            messagebox.showerror("Error", "Las contraseñas no coinciden.")
            return
        usuarios = cargar_usuarios()
        usuarios[dni]["contraseña"] = nueva
        with open(USUARIOS_FILE, "w") as f:
            json.dump(usuarios, f, indent=4)
        messagebox.showinfo("Éxito", "Contraseña actualizada correctamente.")
        ventana_cambiar.destroy()

    ventana_cambiar = tk.Toplevel()
    ventana_cambiar.title("Cambiar Contraseña")
    ventana_cambiar.geometry("300x200")

    tk.Label(ventana_cambiar, text="Nueva Contraseña:").pack(pady=5)
    entry_nueva = tk.Entry(ventana_cambiar, show="*", width=30)
    entry_nueva.pack()

    tk.Label(ventana_cambiar, text="Confirmar Contraseña:").pack(pady=5)
    entry_confirmar = tk.Entry(ventana_cambiar, show="*", width=30)
    entry_confirmar.pack()

    tk.Button(ventana_cambiar, text="Guardar", command=guardar_nueva_contra).pack(pady=10)

    tk.Button(ventana, text="¿Olvidaste tu contraseña?", command=recuperar_contraseña).pack(pady=5)
# --- FIN RECUPERAR CONTRASEÑA ---

ventana.mainloop()