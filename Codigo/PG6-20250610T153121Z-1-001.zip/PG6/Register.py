# register.py
import tkinter as tk
from tkinter import messagebox
import json
import os
import subprocess

# Ruta donde se guardarán los usuarios
USUARIOS_FILE = "usuarios.json"

def guardar_usuario(dni, datos):
    try:
        if os.path.exists(USUARIOS_FILE):
            with open(USUARIOS_FILE, "r") as f:
                usuarios = json.load(f)
        else:
            usuarios = {}

        if dni in usuarios:
            messagebox.showerror("Error", "El DNI ya está registrado.")
            return False

        usuarios[dni] = datos

        with open(USUARIOS_FILE, "w") as f:
            json.dump(usuarios, f, indent=4)

        return True
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo guardar: {e}")
        return False

def registrar():
    nombre = entry_nombre.get()
    dni = entry_dni.get()
    correo = entry_correo.get()
    contra = entry_contra.get()
    confirmar = entry_confirmar.get()
    fecha_nac = entry_fecha.get()


    if not all([nombre, dni, correo, contra, confirmar, edad]):
        messagebox.showwarning("Campos incompletos", "Completa todos los campos.")
        return

    if not dni.isdigit() or len(dni) < 8:
        messagebox.showerror("DNI inválido", "Debe tener al menos 8 dígitos.")
        return

    if contra != confirmar:
        messagebox.showerror("Error", "Las contraseñas no coinciden.")
        return

        from datetime import datetime
        try:
            datetime.strptime(fecha_nac, "%d/%m/%Y")
        except ValueError:
            messagebox.showerror("Fecha inválida", "Introduce una fecha válida con el formato dd/mm/aaaa.")
    return


    datos = {
        "nombre": nombre,
        "correo": correo,
        "contraseña": contra,
        "fecha_nacimiento": fecha_nac
        }

    if guardar_usuario(dni, datos):
        messagebox.showinfo("Éxito", "Registro completo. Ahora puedes iniciar sesión.")
        ventana.destroy()
        subprocess.run(["python", "login.py"])

def volver_al_login():
    ventana.destroy()
    subprocess.run(["python3", "login.py"])

# Interfaz de registro
ventana = tk.Tk()
ventana.title("Registro de Usuario")
ventana.geometry("350x420")
ventana.resizable(False, False)

tk.Label(ventana, text="Nombre y Apellido:").pack()
entry_nombre = tk.Entry(ventana, width=30)
entry_nombre.pack()

tk.Label(ventana, text="Correo Electrónico:").pack()
entry_correo = tk.Entry(ventana, width=30)
entry_correo.pack()

tk.Label(ventana, text="Contraseña:").pack()
entry_contra = tk.Entry(ventana, show="*", width=30)
entry_contra.pack()

tk.Label(ventana, text="Confirmar Contraseña:").pack()
entry_confirmar = tk.Entry(ventana, show="*", width=30)
entry_confirmar.pack()

tk.Label(ventana, text="Fecha de Nacimiento (dd/mm/aaaa):").pack()
entry_fecha = tk.Entry(ventana, width=30)
entry_fecha.pack()

tk.Label(ventana, text="Número de Documento (DNI):").pack()
entry_dni = tk.Entry(ventana, width=30)
entry_dni.pack()

tk.Button(ventana, text="Registrarse", command=registrar).pack(pady=10)
tk.Button(ventana, text="Volver al Login", command=volver_al_login).pack()

ventana.mainloop()
