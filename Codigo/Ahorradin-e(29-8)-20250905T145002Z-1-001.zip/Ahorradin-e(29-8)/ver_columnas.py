import sqlite3

conn = sqlite3.connect("ahorradinn.db")
cursor = conn.cursor()
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
for row in cursor.fetchall():
    print(row[0])


print("\nColumnas de la tabla 'usuario':")
cursor.execute("PRAGMA table_info(usuario);")
for row in cursor.fetchall():
    print(row)

print("\nDatos de la tabla 'usuario':")
cursor.execute("SELECT * FROM usuario;")
for row in cursor.fetchall():
    print(row)

conn.close()