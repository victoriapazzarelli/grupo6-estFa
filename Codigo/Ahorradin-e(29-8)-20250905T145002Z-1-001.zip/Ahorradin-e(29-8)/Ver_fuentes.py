import tkinter as tk
import tkinter.font as tkFont

root = tk.Tk()
fuentes = tkFont.families()
print(fuentes)
root.destroy()

