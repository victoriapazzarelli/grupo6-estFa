import customtkinter as ctk
from tkinter import messagebox
import subprocess
import os
import random
import smtplib
from email.mime.text import MIMEText
import sqlite3

from estilos import configurar_ventana, estilo_label, estilo_entry, estilo_boton

def conectar_db():
    return sqlite3.connect("ahorradinn.db")

def login():
    dni = entry_dni.get().strip()
    contra = entry_contra.get().strip()

    if not dni or not contra:
        messagebox.showwarning("Campos vacíos", "Por favor, complete ambos campos.")
        return

    conn = conectar_db()
    cursor = conn.cursor()
    cursor.execute("SELECT nombre_apellido_usuario, contraseña_usuario FROM usuario WHERE id_usuario = ?", (dni,))
    row = cursor.fetchone()
    conn.close()

    if row:
        nombre_db, contra_db = row
        if contra == contra_db:
            ventana.destroy()
            subprocess.run(["python3", "Pantalla_Principal.py", nombre_db])
        else:
            messagebox.showerror("Error", "Contraseña incorrecta.")
    else:
        messagebox.showerror("Error", "DNI no encontrado.")

def ir_a_registro():
    ventana.destroy()
    subprocess.run(["python3", "Register.py"])  

def enviar_correo(destinatario, codigo):
    remitente = "proyectosfinanzasg6@gmail.com"
    password = "zspo jcwv peem aivl"        
    asunto = "Código de recuperación"
    cuerpo = f"Tu código de recuperación es: {codigo}"

    msg = MIMEText(cuerpo)
    msg["Subject"] = asunto
    msg["From"] = remitente
    msg["To"] = destinatario

    try:
        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
            server.login(remitente, password)
            server.sendmail(remitente, destinatario, msg.as_string())
        return True
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo enviar el correo: {e}")
        return False

def recuperar_contraseña():
    def enviar_codigo():
        dni = entry_dni_rec.get()
        conn = conectar_db()
        cursor = conn.cursor()
        cursor.execute("SELECT correo_electronico_usuario FROM usuario WHERE id_usuario = ?", (dni,))
        row = cursor.fetchone()
        conn.close()
        if row:
            codigo = str(random.randint(100000, 999999))
            correo_usuario = row[0]
            if enviar_correo(correo_usuario, codigo):
                messagebox.showinfo("Código enviado", f"El código fue enviado a: {correo_usuario}")
                ventana_codigo(codigo, dni)
                ventana_rec.destroy()
        else:
            messagebox.showerror("Error", "DNI no encontrado.")

    ventana_rec = ctk.CTkToplevel()
    ventana_rec.title("Recuperar Contraseña")
    ventana_rec.geometry("300x150")
    configurar_ventana(ventana_rec)

    label_rec = ctk.CTkLabel(ventana_rec, text="Introduce tu DNI:")
    label_rec.pack(pady=5)
    estilo_label(label_rec)

    entry_dni_rec = ctk.CTkEntry(ventana_rec, width=250)
    entry_dni_rec.pack(pady=5)
    estilo_entry(entry_dni_rec)

    boton_enviar = ctk.CTkButton(ventana_rec, text="Enviar Código", command=enviar_codigo)
    boton_enviar.pack(pady=10)
    estilo_boton(boton_enviar)

def ventana_codigo(codigo_real, dni):
    def verificar_codigo():
        if entry_codigo.get() == codigo_real:
            cambiar_contraseña(dni)
            ventana_cod.destroy()
        else:
            messagebox.showerror("Código incorrecto", "El código no es válido.")

    ventana_cod = ctk.CTkToplevel()
    ventana_cod.title("Verificar Código")
    ventana_cod.geometry("300x150")
    configurar_ventana(ventana_cod)

    label_cod = ctk.CTkLabel(ventana_cod, text="Introduce el código recibido:")
    label_cod.pack(pady=5)
    estilo_label(label_cod)

    entry_codigo = ctk.CTkEntry(ventana_cod, width=250)
    entry_codigo.pack(pady=5)
    estilo_entry(entry_codigo)

    boton_verificar = ctk.CTkButton(ventana_cod, text="Verificar", command=verificar_codigo)
    boton_verificar.pack(pady=10)
    estilo_boton(boton_verificar)

def cambiar_contraseña(dni):
    def guardar_nueva_contra():
        nueva = entry_nueva.get()
        confirmar = entry_confirmar.get()
        if nueva != confirmar:
            messagebox.showerror("Error", "Las contraseñas no coinciden.")
            return
        conn = conectar_db()
        cursor = conn.cursor()
        cursor.execute("UPDATE usuario SET contraseña_usuario = ? WHERE id_usuario = ?", (nueva, dni))
        conn.commit()
        conn.close()
        messagebox.showinfo("Éxito", "Contraseña actualizada correctamente.")
        ventana_cambiar.destroy()

    ventana_cambiar = ctk.CTkToplevel()
    ventana_cambiar.title("Cambiar Contraseña")
    ventana_cambiar.geometry("300x200")
    configurar_ventana(ventana_cambiar)

    label_nueva = ctk.CTkLabel(ventana_cambiar, text="Nueva Contraseña:")
    label_nueva.pack(pady=5)
    estilo_label(label_nueva)

    entry_nueva = ctk.CTkEntry(ventana_cambiar, show="*", width=250)
    entry_nueva.pack(pady=5)
    estilo_entry(entry_nueva)

    label_confirmar = ctk.CTkLabel(ventana_cambiar, text="Confirmar Contraseña:")
    label_confirmar.pack(pady=5)
    estilo_label(label_confirmar)

    entry_confirmar = ctk.CTkEntry(ventana_cambiar, show="*", width=250)
    entry_confirmar.pack(pady=5)
    estilo_entry(entry_confirmar)

    boton_guardar = ctk.CTkButton(ventana_cambiar, text="Guardar", command=guardar_nueva_contra)
    boton_guardar.pack(pady=10)
    estilo_boton(boton_guardar)

# --- Interfaz Principal ---

ctk.set_appearance_mode("System")  # "Dark", "Light", "System"
ctk.set_default_color_theme("blue")

ventana = ctk.CTk()
ventana.title("Iniciar Sesión")
ventana.geometry("300x400")
ventana.resizable(False, False)
configurar_ventana(ventana)

label_dni = ctk.CTkLabel(ventana, text="Número de Documento (DNI):")
label_dni.pack(pady=5)
estilo_label(label_dni)

entry_dni = ctk.CTkEntry(ventana, width=250)
entry_dni.pack(pady=5)
estilo_entry(entry_dni)

label_contra = ctk.CTkLabel(ventana, text="Contraseña:")
label_contra.pack(pady=5)
estilo_label(label_contra)

entry_contra = ctk.CTkEntry(ventana, show="*", width=250)
entry_contra.pack(pady=5)
estilo_entry(entry_contra)

boton_login = ctk.CTkButton(ventana, text="Iniciar Sesión", command=login)
boton_login.pack(pady=15)
estilo_boton(boton_login)

boton_registro = ctk.CTkButton(ventana, text="Registrarse", command=ir_a_registro)
boton_registro.pack(pady=5)
estilo_boton(boton_registro)

boton_olvido = ctk.CTkButton(ventana, text="¿Olvidaste tu contraseña?", command=recuperar_contraseña)
boton_olvido.pack(pady=5)
estilo_boton(boton_olvido)

ventana.mainloop()