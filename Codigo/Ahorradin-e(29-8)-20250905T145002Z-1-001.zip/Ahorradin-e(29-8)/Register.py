import customtkinter as ctk
from tkinter import messagebox
import sqlite3
import subprocess
from estilos import configurar_ventana, estilo_label, estilo_entry, estilo_boton

DB_FILE = "ahorradinn.db"

def guardar_usuario(dni, nombre, correo, contra, fecha_nac):
    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        # Verifica si el usuario ya existe
        cursor.execute("SELECT 1 FROM usuario WHERE id_usuario = ?", (dni,))
        if cursor.fetchone():
            messagebox.showerror("Error", "El DNI ya está registrado.")
            conn.close()
            return False
        # Inserta el nuevo usuario
        cursor.execute("""
            INSERT INTO usuario (
                id_usuario, 
                nombre_apellido_usuario, 
                contraseña_usuario, 
                correo_electronico_usuario, 
                fecha_registro_usuario, 
                saldo_inicial
            ) VALUES (?, ?, ?, ?, ?, ?)
        """, (dni, nombre, contra, correo, fecha_nac, 0.0))
        conn.commit()
        conn.close()
        return True
    except sqlite3.IntegrityError:
        messagebox.showerror("Error", "El DNI o correo ya están registrados.")
        return False
    except Exception as e:
        messagebox.showerror("Error", f"No se pudo guardar: {e}")
        return False

def registrar():
    nombre = entry_nombre.get()
    dni = entry_dni.get()
    correo = entry_correo.get()
    contra = entry_contra.get()
    confirmar = entry_confirmar.get()
    fecha_nac = entry_fecha.get()

    if not all([nombre, dni, correo, contra, confirmar, fecha_nac]):
        messagebox.showwarning("Campos incompletos", "Completa todos los campos.")
        return

    if "@" not in correo:
        messagebox.showerror("Correo inválido", "El correo debe contener un '@'.")
        return

    if not dni.isdigit() or len(dni) < 8:
        messagebox.showerror("DNI inválido", "Debe tener al menos 8 dígitos.")
        return

    if contra != confirmar:
        messagebox.showerror("Error", "Las contraseñas no coinciden.")
        return

    from datetime import datetime
    try:
        fecha_sql = datetime.strptime(fecha_nac, "%d/%m/%Y").strftime("%Y-%m-%d")
    except ValueError:
        messagebox.showerror("Fecha inválida", "Introduce una fecha válida con el formato dd/mm/aaaa.")
        return

    if guardar_usuario(dni, nombre, correo, contra, fecha_sql):
        messagebox.showinfo("Éxito", "Registro completo. Ahora puedes iniciar sesión.")
        ventana.destroy()
        subprocess.run(["python3", "login.py"])

def volver_al_login():
    ventana.destroy()
    subprocess.run(["python3", "login.py"])

# --- Interfaz ---

ctk.set_appearance_mode("System")  # "Dark", "Light" o "System"
ctk.set_default_color_theme("blue")

ventana = ctk.CTk()
ventana.title("Registro de Usuario")
ventana.geometry("350x520")
ventana.resizable(False, False)
configurar_ventana(ventana)

labels_text = [
    "Nombre y Apellido:",
    "Correo Electrónico:",
    "Contraseña:",
    "Confirmar Contraseña:",
    "Fecha de Nacimiento (dd/mm/aaaa):",
    "Número de Documento (DNI):"
]

entries = []

for texto in labels_text:
    label = ctk.CTkLabel(ventana, text=texto)
    estilo_label(label)
    label.pack(pady=(8, 2))
    entry = ctk.CTkEntry(ventana, width=300)
    estilo_entry(entry)
    entry.pack(pady=(0, 5))
    entries.append(entry)

entry_nombre, entry_correo, entry_contra, entry_confirmar, entry_fecha, entry_dni = entries

entry_contra.configure(show="*")
entry_confirmar.configure(show="*")

boton_registrar = ctk.CTkButton(ventana, text="Registrarse", command=registrar)
estilo_boton(boton_registrar)
boton_registrar.pack(pady=15)

boton_volver = ctk.CTkButton(ventana, text="Volver al Login", command=volver_al_login)
estilo_boton(boton_volver)
boton_volver.pack()

ventana.mainloop()


