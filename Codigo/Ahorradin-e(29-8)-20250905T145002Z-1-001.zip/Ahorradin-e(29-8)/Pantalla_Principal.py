import tkinter as tk
from tkinter import font
import subprocess
import sys
import sqlite3
from tkinter import messagebox  # <--- Agrega esta importación
import datetime

class App(tk.Tk):
    def mostrar_configuracion(self):
        # Oculta otras áreas si están activas
        if self.monto_area_activa:
            self.ocultar_monto_disponible()
        if self.movimientos_area_activa:
            self.ocultar_movimientos()
        # Limpia el área principal
        for widget in self.main_area.winfo_children():
            widget.destroy()

        # Obtiene los datos actuales del usuario
        try:
            conn = sqlite3.connect("ahorradinn.db")
            cursor = conn.cursor()
            cursor.execute("SELECT nombre_apellido_usuario, contraseña_usuario, correo_electronico_usuario, fecha_registro_usuario, saldo_inicial, id_usuario FROM usuario WHERE id_usuario=? ORDER BY id_usuario DESC LIMIT 1", (self.id_usuario,))
            datos = cursor.fetchone()
            conn.close()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron obtener los datos: {e}")
            return

        if not datos:
            messagebox.showerror("Error", "No se encontraron datos del usuario.")
            return

        nombre, contrasena, correo, fecha_registro, saldo, id_usuario = datos

        frame = tk.Frame(self.main_area, bg="white")
        frame.pack(pady=40, padx=40)

        tk.Label(frame, text="Editar datos de usuario", font=self.montserrat14, bg="white").grid(row=0, column=0, columnspan=2, pady=(0,20))

        tk.Label(frame, text="Nombre y Apellido:", font=self.montserrat12, bg="white").grid(row=1, column=0, sticky="e", pady=5)
        entry_nombre = tk.Entry(frame, font=self.montserrat12)
        entry_nombre.insert(0, nombre)
        entry_nombre.grid(row=1, column=1, pady=5)

        tk.Label(frame, text="Correo electrónico:", font=self.montserrat12, bg="white").grid(row=2, column=0, sticky="e", pady=5)
        entry_correo = tk.Entry(frame, font=self.montserrat12)
        entry_correo.insert(0, correo)
        entry_correo.grid(row=2, column=1, pady=5)

        tk.Label(frame, text="Contraseña:", font=self.montserrat12, bg="white").grid(row=3, column=0, sticky="e", pady=5)
        entry_contra = tk.Entry(frame, font=self.montserrat12, show="*")
        entry_contra.insert(0, contrasena)
        entry_contra.grid(row=3, column=1, pady=5)

        tk.Label(frame, text="Fecha de nacimiento:", font=self.montserrat12, bg="white").grid(row=4, column=0, sticky="e", pady=5)
        entry_fecha = tk.Entry(frame, font=self.montserrat12)
        entry_fecha.insert(0, fecha_registro)
        entry_fecha.config(state="readonly")
        entry_fecha.grid(row=4, column=1, pady=5)
        entry_fecha.grid(row=4, column=1, pady=5)


        tk.Label(frame, text="ID Usuario:", font=self.montserrat12, bg="white").grid(row=6, column=0, sticky="e", pady=5)
        entry_id = tk.Entry(frame, font=self.montserrat12)
        entry_id.insert(0, id_usuario)
        entry_id.config(state="readonly")
        entry_id.grid(row=6, column=1, pady=5)

        import random
        import smtplib
        from email.mime.text import MIMEText
        def enviar_correo(destinatario, codigo):
            remitente = "proyectosfinanzasg6@gmail.com"
            password = "zspo jcwv peem aivl"
            asunto = "Código de verificación de cambio de contraseña"
            cuerpo = f"Tu código de verificación es: {codigo}"
            msg = MIMEText(cuerpo)
            msg["Subject"] = asunto
            msg["From"] = remitente
            msg["To"] = destinatario
            try:
                with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
                    server.login(remitente, password)
                    server.sendmail(remitente, destinatario, msg.as_string())
                return True
            except Exception as e:
                messagebox.showerror("Error", f"No se pudo enviar el correo: {e}")
                return False

        def guardar_cambios():
            nuevo_nombre = entry_nombre.get().strip()
            nuevo_correo = entry_correo.get().strip()
            nueva_contra = entry_contra.get().strip()
            # Validaciones básicas
            if not nuevo_nombre or not nuevo_correo or not nueva_contra:
                messagebox.showwarning("Campos vacíos", "Todos los campos editables son obligatorios.")
                return
            # Si la contraseña cambió, primero verificación por correo
            def pedir_contraseña_y_guardar():
                def verificar_contraseña():
                    ingresada = entry_contra_actual.get().strip()
                    if ingresada == contrasena:
                        ventana_contra.destroy()
                        guardar_en_db()
                    else:
                        messagebox.showerror("Error", "Contraseña actual incorrecta.")
                ventana_contra = tk.Toplevel(self)
                ventana_contra.title("Verificar contraseña")
                tk.Label(ventana_contra, text="Ingrese su contraseña actual para guardar los cambios:").pack(padx=10, pady=10)
                entry_contra_actual = tk.Entry(ventana_contra, show="*")
                entry_contra_actual.pack(padx=10, pady=5)
                tk.Button(ventana_contra, text="Verificar", command=verificar_contraseña).pack(pady=10)

            if nueva_contra != contrasena:
                codigo = str(random.randint(100000, 999999))
                if enviar_correo(nuevo_correo, codigo):
                    def verificar_codigo():
                        ingresado = entry_codigo.get().strip()
                        if ingresado == codigo:
                            ventana_codigo.destroy()
                            pedir_contraseña_y_guardar()
                        else:
                            messagebox.showerror("Error", "Código incorrecto.")
                    ventana_codigo = tk.Toplevel(self)
                    ventana_codigo.title("Verificación de código")
                    tk.Label(ventana_codigo, text="Ingrese el código enviado a su correo:").pack(padx=10, pady=10)
                    entry_codigo = tk.Entry(ventana_codigo)
                    entry_codigo.pack(padx=10, pady=5)
                    tk.Button(ventana_codigo, text="Verificar", command=verificar_codigo).pack(pady=10)
                else:
                    messagebox.showerror("Error", "No se pudo enviar el correo de verificación.")
                return
            else:
                pedir_contraseña_y_guardar()

        def guardar_en_db():
            try:
                conn = sqlite3.connect("ahorradinn.db")
                cursor = conn.cursor()
                cursor.execute("UPDATE usuario SET nombre_apellido_usuario=?, correo_electronico_usuario=?, contraseña_usuario=? WHERE id_usuario=?", (entry_nombre.get().strip(), entry_correo.get().strip(), entry_contra.get().strip(), self.id_usuario))
                conn.commit()
                conn.close()
                messagebox.showinfo("Éxito", "Datos actualizados correctamente.")
                self.nombre_usuario = entry_nombre.get().strip()
                self._build_sidebar()  # Actualiza el nombre en el menú
            except Exception as e:
                messagebox.showerror("Error", f"No se pudieron guardar los cambios: {e}")

        btn_guardar = tk.Button(frame, text="Guardar cambios", font=self.montserrat12, bg="#129cff", fg="white", command=guardar_cambios)
        btn_guardar.grid(row=7, column=0, columnspan=2, pady=20)
    def __init__(self, nombre_usuario="Usuario"):
        super().__init__()
        self.nombre_usuario = nombre_usuario
        self.title("Interfaz de Usuario")
        self.geometry("800x600")
        self.configure(bg="#71c4ff")          # Color de fondo principal
        self.configuracion_area_activa = False  # Switch para Configuración

        # Cargar fuente Montserrat
        try:
            self.montserrat14 = font.Font(family="Montserrat", size=14)
            self.montserrat12 = font.Font(family="Montserrat", size=12)
        except:
            # Caída a la fuente por defecto si Montserrat no está instalada
            self.montserrat14 = font.Font(size=14)
            self.montserrat12 = font.Font(size=12)

        self.main_area = None  # Guarda referencia al área principal
        self.monto_visible = True  # Estado de visibilidad del monto
        self.monto_actual = ""     # Guarda el monto real
        self.monto_area_activa = False  # Estado del switch de "Monto Disponible"
        self.movimientos_area_activa = False  # Switch para "Movimientos"
        self.gasto_popup = None  # Referencia a la ventana de gasto
        self.gasto_form_frame = None  # Añade esta línea para evitar el error de atributo
        # Elimina self.gasto_form_frame

        self.id_usuario = self.obtener_id_usuario(self.nombre_usuario)

        self._build_sidebar()
        self._build_main_area()

    def obtener_id_usuario(self, nombre_usuario):
        try:
            conn = sqlite3.connect("ahorradinn.db")
            cursor = conn.cursor()
            cursor.execute(
                "SELECT id_usuario FROM usuario WHERE nombre_apellido_usuario=? ORDER BY id_usuario DESC LIMIT 1",
                (nombre_usuario,)
            )
            resultado = cursor.fetchone()
            conn.close()
            if resultado:
                return resultado[0]
        except Exception as e:
            print("Error al obtener id_usuario:", e)
        return None

    def _build_sidebar(self):
        # Eliminar sidebar anterior si existe
        if hasattr(self, 'sidebar') and self.sidebar.winfo_exists():
            self.sidebar.destroy()
        # Marco lateral
        self.sidebar = tk.Frame(self, bg="#587fb2", width=200)
        self.sidebar.pack(side="left", fill="y")

        # Label de bienvenida con el nombre real
        welcome = tk.Label(
            self.sidebar,
            text=f"Bienvenido, {self.nombre_usuario}",
            bg="#587fb2",
            fg="black",
            font=self.montserrat14
        )
        welcome.pack(pady=(30, 20))

        # Botones del menú
        self.menu_botones = {}  # Guarda referencia a los botones del menú
        opciones = [
            "Monto Disponible",
            "Movimientos",
            "Metas",
            "Boletas",
            "Categorías",
            "Configuración",
            "Cerrar Sesión"
        ]
        for texto in opciones:
            btn = tk.Button(
                self.sidebar,
                text=texto,
                font=self.montserrat12,
                bg="#129cff",
                fg="white",
                activebackground="#0d8adc",
                activeforeground="white",
                bd=0,
                relief="flat",
                width=20,
                command=lambda t=texto: self.on_menu_click(t)
            )
            btn.pack(pady=5, padx=10)
            self.menu_botones[texto] = btn  # Guardar referencia

    def _build_main_area(self):
        # Marco principal
        self.main_area = tk.Frame(self, bg="white")
        self.main_area.pack(side="right", expand=True, fill="both")

        # Frame para agrupar los botones de monto en la parte superior derecha
        self.monto_btn_frame = tk.Frame(self.main_area, bg="white")
        # No hacer pack aquí, solo cuando esté activo

        # Botón "Resetear Monto" pequeño y espaciado
        self.btn_reset_monto = tk.Button(
            self.monto_btn_frame,
            text="Resetear",
            font=self.montserrat12,
            bg="#129cff",
            fg="white",
            activebackground="#0d8adc",
            activeforeground="white",
            bd=0,
            relief="flat",
            width=10,   # Más pequeño
            height=1,
            command=self.resetear_monto
        )
        # No hacer pack aquí, solo cuando esté activo

        # Botón "Cargar Monto"
        self.btn_cargar_monto = tk.Button(
            self.monto_btn_frame,
            text="Cargar Monto",
            font=self.montserrat12,
            bg="#129cff",
            fg="white",
            activebackground="#0d8adc",
            activeforeground="white",
            bd=0,
            relief="flat",
            width=20,
            height=2,
            command=self.cargar_monto_popup
        )
        # No hacer pack aquí, solo cuando esté activo

        # Frame horizontal para monto y censura
        self.monto_frame = tk.Frame(self.main_area, bg="white")
        # No hacer pack aquí, solo cuando esté activo

        detalles = ""
        self.lbl_detalles = tk.Label(
            self.monto_frame,  # Cambia el parent al frame
            text=detalles,
            bg="white",
            fg="black",
            font=self.montserrat12,
            justify="left"
        )
        self.lbl_detalles.pack(side="left", pady=40, padx=(20,0), anchor="w")

        self.btn_censurar = tk.Button(
            self.monto_frame,  # Cambia el parent al frame
            text="👁️",
            font=self.montserrat12,
            bg="#e0e0e0",
            fg="black",
            bd=0,
            relief="flat",
            width=2,
            command=self.toggle_monto
        )
        self.btn_censurar.pack(side="left", pady=40, padx=(10,20), anchor="w")

    def registrar_evento(self, tipo, monto, descripcion=""):
        """
        Registra en la tabla 'movimiento' cada vez que se carga monto, se registra un gasto o se resetea el monto.
        tipo: 'carga', 'gasto', 'reseteo'
        monto: cantidad afectada (float)
        descripcion: texto opcional
        """
        try:
            conn = sqlite3.connect("ahorradinn.db")
            cursor = conn.cursor()
            # Determina si es ingreso o gasto
            ingreso_o_gasto = "ingreso" if tipo == "carga" else "gasto" if tipo == "gasto" else "reseteo"
            # Usa la categoría 1 por defecto (puedes cambiar esto si tienes lógica de categorías)
            id_categoria = 1
            hora = datetime.datetime.now().strftime("%H:%M:%S")
            fecha = datetime.datetime.now().strftime("%Y-%m-%d")
            cursor.execute(
                "INSERT INTO movimiento (id_usuario, id_categoria, monto_movimiento, descripcion_movimiento, ingreso_o_gasto_movimiento, hora_movimiento, fecha_movimiento) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (self.id_usuario, id_categoria, monto, descripcion, ingreso_o_gasto, hora, fecha)
            )
            conn.commit()
            conn.close()
        except Exception as e:
            print("Error al registrar evento:", e)

    def cargar_monto_popup(self):
        popup = tk.Toplevel(self)
        popup.title("Cargar Monto")
        popup.geometry("300x150")
        popup.configure(bg="white")

        lbl = tk.Label(popup, text="Ingrese el monto a cargar:", bg="white", font=self.montserrat12)
        lbl.pack(pady=10)

        entry = tk.Entry(popup, font=self.montserrat12)
        entry.pack(pady=5)

        def cargar():
            try:
                monto = float(entry.get())
                self.sumar_monto_usuario(self.nombre_usuario, monto)
                self.registrar_evento("carga", monto)  # Registrar evento de carga
                popup.destroy()
                self.mostrar_monto_disponible() 
            except ValueError:
                lbl.config(text="Ingrese un monto válido.", fg="red")

        btn = tk.Button(popup, text="Cargar", font=self.montserrat12, bg="#129cff", fg="white", command=cargar)
        btn.pack(pady=10)

    def mostrar_monto_disponible(self):
        # Activar área de monto
        if not self.monto_area_activa:
            self.monto_area_activa = True
            self.menu_botones["Monto Disponible"].config(bg="#0d8adc")
            # Si el frame fue destruido, recrearlo
            if not hasattr(self, 'monto_btn_frame') or not self.monto_btn_frame.winfo_exists():
                self.monto_btn_frame = tk.Frame(self.main_area, bg="white")
                self.btn_reset_monto = tk.Button(
                    self.monto_btn_frame,
                    text="Resetear",
                    font=self.montserrat12,
                    bg="#129cff",
                    fg="white",
                    activebackground="#0d8adc",
                    activeforeground="white",
                    bd=0,
                    relief="flat",
                    width=10,
                    height=1,
                    command=self.resetear_monto
                )
                self.btn_cargar_monto = tk.Button(
                    self.monto_btn_frame,
                    text="Cargar Monto",
                    font=self.montserrat12,
                    bg="#129cff",
                    fg="white",
                    activebackground="#0d8adc",
                    activeforeground="white",
                    bd=0,
                    relief="flat",
                    width=20,
                    height=2,
                    command=self.cargar_monto_popup
                )
            self.monto_btn_frame.pack(pady=10, padx=10, anchor="ne")
            self.btn_reset_monto.pack(side="left", padx=(0,10))
            self.btn_cargar_monto.pack(side="left")
            if not hasattr(self, 'monto_frame') or not self.monto_frame.winfo_exists():
                self.monto_frame = tk.Frame(self.main_area, bg="white")
                self.lbl_detalles = tk.Label(
                    self.monto_frame,
                    text="",
                    bg="white",
                    fg="black",
                    font=self.montserrat12,
                    justify="left"
                )
                self.lbl_detalles.pack(side="left", pady=40, padx=(20,0), anchor="w")
                self.btn_censurar = tk.Button(
                    self.monto_frame,
                    text="👁️",
                    font=self.montserrat12,
                    bg="#e0e0e0",
                    fg="black",
                    bd=0,
                    relief="flat",
                    width=2,
                    command=self.toggle_monto
                )
                self.btn_censurar.pack(side="left", pady=40, padx=(10,20), anchor="w")
            self.monto_frame.pack(pady=40, padx=0, anchor="nw")
        monto = self.obtener_ultimo_monto_usuario(self.nombre_usuario)
        self.monto_actual = monto if monto is not None else 0
        self.actualizar_monto_label()
        # Si el formulario de gasto está abierto y se oculta la pestaña, también se oculta el formulario
        if self.gasto_form_frame:
            self.gasto_form_frame.pack_forget()
            self.gasto_form_frame = None

    def ocultar_monto_disponible(self):
        # Desactivar área de monto
        if self.monto_area_activa:
            self.monto_area_activa = False
            self.menu_botones["Monto Disponible"].config(bg="#129cff")
            if hasattr(self, 'monto_btn_frame') and self.monto_btn_frame.winfo_exists():
                self.monto_btn_frame.pack_forget()
            if hasattr(self, 'btn_reset_monto') and self.btn_reset_monto.winfo_exists():
                self.btn_reset_monto.pack_forget()
            if hasattr(self, 'btn_cargar_monto') and self.btn_cargar_monto.winfo_exists():
                self.btn_cargar_monto.pack_forget()
            if hasattr(self, 'monto_frame') and self.monto_frame.winfo_exists():
                self.monto_frame.pack_forget()
            if hasattr(self, 'lbl_detalles'):
                self.lbl_detalles.config(text="")
            if self.gasto_form_frame:
                self.gasto_form_frame.pack_forget()
                self.gasto_form_frame = None

    def resetear_monto(self):
        # Ventana de confirmación antes de resetear
        respuesta = messagebox.askyesno("Confirmar", "¿Seguro que deseas resetear el monto a 0?")
        if not respuesta:
            return
        try:
            conn = sqlite3.connect("ahorradinn.db")
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE usuario SET saldo_inicial=? WHERE nombre_apellido_usuario=?",
                (0, self.nombre_usuario)
            )
            conn.commit()
            conn.close()
            self.registrar_evento("reseteo", 0)  # Registrar evento de reseteo
            self.mostrar_monto_disponible()
        except Exception as e:
            print("Error al resetear monto:", e)

    def actualizar_monto_label(self):
        if self.monto_area_activa:
            if self.monto_visible:
                texto = f"Tu monto disponible es: ${self.monto_actual}"
            else:
                texto = "Tu monto disponible es: *****"
            self.lbl_detalles.config(text=texto)
        else:
            self.lbl_detalles.config(text="")

    def toggle_monto(self):
        self.monto_visible = not self.monto_visible
        self.actualizar_monto_label()

    def obtener_ultimo_monto_usuario(self, usuario):
        try:
            conn = sqlite3.connect("ahorradinn.db")
            cursor = conn.cursor()
            cursor.execute(
                "SELECT saldo_inicial FROM usuario WHERE nombre_apellido_usuario=? ORDER BY id_usuario DESC LIMIT 1",
                (usuario,)
            )
            resultado = cursor.fetchone()
            conn.close()
            if resultado:
                return resultado[0]
        except Exception as e:
            print("Error al consultar la base de datos:", e)
        return None

    def sumar_monto_usuario(self, usuario, monto):
        try:
            conn = sqlite3.connect("ahorradinn.db")
            cursor = conn.cursor()
            # Obtener el saldo actual
            cursor.execute(
                "SELECT saldo_inicial FROM usuario WHERE nombre_apellido_usuario=? ORDER BY id_usuario DESC LIMIT 1",
                (usuario,)
            )
            resultado = cursor.fetchone()
            saldo_actual = resultado[0] if resultado else 0
            nuevo_saldo = saldo_actual + monto
            # Actualizar el saldo del usuario
            cursor.execute(
                "UPDATE usuario SET saldo_inicial=? WHERE nombre_apellido_usuario=?",
                (nuevo_saldo, usuario)
            )
            conn.commit()
            conn.close()
        except Exception as e:
            print("Error al cargar monto:", e)

    def mostrar_movimientos(self):
        if not self.movimientos_area_activa:
            self.movimientos_area_activa = True
            self.menu_botones["Movimientos"].config(bg="#0d8adc")
            # Crear frame y botón en la parte superior solo cuando el switch está activo
            self.movimientos_btn_frame = tk.Frame(self.main_area, bg="white")
            self.movimientos_btn_frame.pack(pady=10, padx=10, anchor="ne")
            self.btn_cargar_gasto = tk.Button(
                self.movimientos_btn_frame,
                text="Cargar Gasto",
                font=self.montserrat12,
                bg="#129cff",
                fg="white",
                activebackground="#0d8adc",
                activeforeground="white",
                bd=0,
                relief="flat",
                width=20,
                height=2,
                command=self.cargar_gasto_popup
            )
            self.btn_cargar_gasto.pack(side="left")

            # Historial de movimientos (últimos 10)
            self.historial_frame = tk.Frame(self.main_area, bg="white")
            self.historial_frame.pack(pady=10, padx=10, anchor="nw", fill="x")
            self.mostrar_historial_movimientos()

    def ocultar_movimientos(self):
        if self.movimientos_area_activa:
            self.movimientos_area_activa = False
            self.menu_botones["Movimientos"].config(bg="#129cff")
            if self.movimientos_btn_frame:
                self.movimientos_btn_frame.pack_forget()
                self.movimientos_btn_frame.destroy()
                self.movimientos_btn_frame = None
                self.btn_cargar_gasto = None
            if hasattr(self, "historial_frame") and self.historial_frame:
                self.historial_frame.pack_forget()
                self.historial_frame.destroy()
                self.historial_frame = None
            if self.gasto_popup is not None:
                self.gasto_popup.destroy()
                self.gasto_popup = None

    def mostrar_historial_movimientos(self):
        # Consulta los últimos 10 movimientos del usuario
        try:
            conn = sqlite3.connect("ahorradinn.db")
            cursor = conn.cursor()
            cursor.execute(
                """
                SELECT monto_movimiento, descripcion_movimiento, ingreso_o_gasto_movimiento, fecha_movimiento, hora_movimiento
                FROM movimiento
                WHERE id_usuario = ?
                ORDER BY id_movimiento DESC
                LIMIT 10
                """,
                (self.id_usuario,)
            )
            movimientos = cursor.fetchall()
            conn.close()
        except Exception as e:
            movimientos = []
            print("Error al consultar historial de movimientos:", e)

        # Limpia el frame antes de mostrar
        for widget in self.historial_frame.winfo_children():
            widget.destroy()

        # Título
        tk.Label(self.historial_frame, text="Últimos 10 movimientos", bg="white", font=self.montserrat14).pack(anchor="w", pady=(0,5))

        if not movimientos:
            tk.Label(self.historial_frame, text="No hay movimientos registrados.", bg="white", font=self.montserrat12).pack(anchor="w")
            return

        # Lista de movimientos
        for mov in movimientos:
            monto, desc, tipo, fecha, hora = mov
            texto = f"[{fecha} {hora}] {'+' if tipo=='ingreso' else '-'}${monto} | {tipo.capitalize()} | {desc if desc else 'Sin descripción'}"
            tk.Label(self.historial_frame, text=texto, bg="white", font=self.montserrat12, anchor="w", justify="left").pack(anchor="w")

    def cargar_gasto_popup(self):
        self.gasto_popup = tk.Toplevel(self)
        self.gasto_popup.title("Cargar Gasto")
        self.gasto_popup.geometry("300x200")
        self.gasto_popup.configure(bg="white")

        lbl = tk.Label(self.gasto_popup, text="Monto del gasto:", bg="white", font=self.montserrat12)
        lbl.pack(pady=10)

        entry_monto = tk.Entry(self.gasto_popup, font=self.montserrat12)
        entry_monto.pack(pady=5)

        lbl_desc = tk.Label(self.gasto_popup, text="Descripción (opcional):", bg="white", font=self.montserrat12)
        lbl_desc.pack(pady=5)

        entry_desc = tk.Entry(self.gasto_popup, font=self.montserrat12)
        entry_desc.pack(pady=5)

        def registrar_gasto():
            try:
                monto_gasto = float(entry_monto.get())
                descripcion = entry_desc.get()
                if monto_gasto <= 0:
                    lbl.config(text="El monto debe ser mayor a 0.", fg="red")
                    return
                saldo_actual = self.obtener_ultimo_monto_usuario(self.nombre_usuario)
                if saldo_actual is None or saldo_actual < monto_gasto:
                    lbl.config(text="Saldo insuficiente.", fg="red")
                    return
                nuevo_saldo = saldo_actual - monto_gasto
                conn = sqlite3.connect("ahorradinn.db")
                cursor = conn.cursor()
                cursor.execute(
                    "UPDATE usuario SET saldo_inicial=? WHERE nombre_apellido_usuario=?",
                    (nuevo_saldo, self.nombre_usuario)
                )
                conn.commit()
                conn.close()
                self.registrar_evento("gasto", monto_gasto, descripcion)  # Registrar evento de gasto
                self.mostrar_monto_disponible()
                self.gasto_popup.destroy()
                self.gasto_popup = None
                self.ocultar_movimientos()
            except ValueError:
                lbl.config(text="Ingrese un monto válido.", fg="red")

        btn_registrar = tk.Button(self.gasto_popup, text="Registrar", font=self.montserrat12, bg="#129cff", fg="white", command=registrar_gasto)
        btn_registrar.pack(pady=10)

        def cerrar_popup():
            self.gasto_popup.destroy()
            self.gasto_popup = None

        self.gasto_popup.protocol("WM_DELETE_WINDOW", cerrar_popup)

    def on_menu_click(self, opcion):
        # Permite solo un switch activo a la vez: si se selecciona uno, cierra el otro si está activo
        if opcion == "Cerrar Sesión":
            self.cerrar_sesion()
        elif opcion == "Monto Disponible":
            if not self.monto_area_activa:
                if self.movimientos_area_activa:
                    self.ocultar_movimientos()
                if self.configuracion_area_activa:
                    self.ocultar_configuracion()
                self.mostrar_monto_disponible()
            else:
                self.ocultar_monto_disponible()
        elif opcion == "Movimientos":
            if not self.movimientos_area_activa:
                if self.monto_area_activa:
                    self.ocultar_monto_disponible()
                if self.configuracion_area_activa:
                    self.ocultar_configuracion()
                self.mostrar_movimientos()
            else:
                self.ocultar_movimientos()
        elif opcion == "Configuración":
            if not self.configuracion_area_activa:
                if self.monto_area_activa:
                    self.ocultar_monto_disponible()
                if self.movimientos_area_activa:
                    self.ocultar_movimientos()
                self.mostrar_configuracion()
                self.configuracion_area_activa = True
                self.menu_botones["Configuración"].config(bg="#0d8adc")
            else:
                self.ocultar_configuracion()
        else:
            # Si se pulsa otro botón, oculta todos los switches si están activos
            if self.monto_area_activa:
                self.ocultar_monto_disponible()
            if self.movimientos_area_activa:
                self.ocultar_movimientos()
            if self.configuracion_area_activa:
                self.ocultar_configuracion()
            for widget in self.main_area.winfo_children():
                widget.destroy()
            print(f"Has pulsado: {opcion}")

    def ocultar_configuracion(self):
        self.configuracion_area_activa = False
        self.menu_botones["Configuración"].config(bg="#129cff")
        for widget in self.main_area.winfo_children():
            widget.destroy()

    def cerrar_sesion(self):
        self.destroy()
        subprocess.run(["python3", "login.py"])


if __name__ == "__main__":
    nombre = "Usuario"
    if len(sys.argv) > 1:
        nombre = sys.argv[1]
    app = App(nombre)
    app.mainloop()