import sqlite3

conn = sqlite3.connect("ahorradinn.db")
cursor = conn.cursor()

# Mostrar todas las tablas
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tablas = cursor.fetchall()
print("Tablas en la base de datos:", tablas)

# Mostrar contenido de cada tabla
for tabla in tablas:
    print(f"\nContenido de la tabla {tabla[0]}:")
    cursor.execute(f"SELECT * FROM {tabla[0]} LIMIT 5;")
    filas = cursor.fetchall()
    for fila in filas:
        print(fila)

conn.close()