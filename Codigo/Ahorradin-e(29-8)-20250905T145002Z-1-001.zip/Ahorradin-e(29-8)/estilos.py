import customtkinter as ctk

# Fuente Montserrat con opción de negrita
def get_fuente_montserrat(tamano=12, negrita=False):
    peso = "bold" if negrita else "normal"
    return ("Montserrat", tamano, peso)

# Configurar ventana con fondo azul
def configurar_ventana(ventana):
    ventana.configure(fg_color="#71c4ff")  # color de fondo azul

# Estilo para etiquetas (labels)
def estilo_label(label, tamano=12, negrita=False):
    label.configure(
        font=get_fuente_montserrat(tamano, negrita),
        text_color="white"
    )

# Estilo para entradas de texto (entry)
def estilo_entry(entry):
    entry.configure(
        font=get_fuente_montserrat(12),
        fg_color="white",
        text_color="black",
        border_width=2,
        border_color="#000000",
        corner_radius=8,
        placeholder_text_color="gray"
    )

# Estilo para botones
def estilo_boton(boton):
    boton.configure(
        font=get_fuente_montserrat(12, True),
        fg_color="#129cff",
        hover_color="#0a6fc1",
        text_color="white",
        corner_radius=12,
        cursor="hand2"
    )



