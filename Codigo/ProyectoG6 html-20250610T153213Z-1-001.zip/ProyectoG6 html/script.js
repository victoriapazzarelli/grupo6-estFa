window.addEventListener("load", () => {
  const loader = document.getElementById("loader");
  setTimeout(() => {
    loader.style.display = "none";
    mostrarFormulario("form-registro"); // Mostrar registro al inicio
  }, 2000);
});

function mostrarFormulario(id) {
  const formularios = document.querySelectorAll('.form-container');
  formularios.forEach(f => f.classList.add('hidden'));

  const target = document.getElementById(id);
  if (target) target.classList.remove('hidden');
}

// Mostrar formulario de nueva contraseña
function mostrarNuevaContrasena() {
  mostrarFormulario("form-nueva-contrasena");
}

function validarRegistro(event) {
  event.preventDefault();

  const form = event.target;
  const inputs = form.querySelectorAll('input');
  const password1 = inputs[2].value;
  const password2 = inputs[3].value;

  if (password1.length < 6) {
    alert('La contraseña debe tener al menos 6 caracteres.');
    return;
  }

  if (password1 !== password2) {
    alert('Las contraseñas no coinciden.');
    return;
  }

  mostrarFormulario('form-login');
}

let codigoVerificado = null;

// Captura email y solicita envío de código
document.getElementById("form-recuperar").addEventListener("submit", function (e) {
  e.preventDefault();
  const email = this.querySelector("input").value;

  fetch("/api/recuperar", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.success) {
        alert("Código enviado al correo");
        mostrarFormulario("form-ingresar-codigo");
      } else {
        alert("Correo no encontrado");
      }
    })
    .catch(() => alert("Ocurrió un error al solicitar el código"));
});

// Paso 1: Verificar código
document.getElementById("form-verificar-codigo").addEventListener("submit", function (e) {
  e.preventDefault();

  const codigo = this.querySelector("input").value;

  fetch("/api/verificar-codigo", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ codigo }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.success) {
        codigoVerificado = codigo;
        mostrarNuevaContrasena();
      } else {
        alert("Código inválido o expirado.");
      }
    })
    .catch(() => alert("Error al verificar el código"));
});

// Paso 2: Cambiar contraseña
document.getElementById("form-cambiar-contrasena").addEventListener("submit", function (e) {
  e.preventDefault();

  const inputs = this.querySelectorAll("input");
  const nueva = inputs[0].value;
  const confirmar = inputs[1].value;

  if (nueva.length < 6) {
    alert("La contraseña debe tener al menos 6 caracteres.");
    return;
  }

  if (nueva !== confirmar) {
    alert("Las contraseñas no coinciden.");
    return;
  }

  fetch("/api/cambiar-contrasena", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ codigo: codigoVerificado, nueva }),
  })
    .then((res) => res.json())
    .then((data) => {
      if (data.success) {
        alert("Contraseña cambiada correctamente.");
        mostrarFormulario("form-login");
      } else {
        alert("Hubo un problema al cambiar la contraseña.");
      }
    })
    .catch(() => alert("Error al cambiar la contraseña"));
});


  